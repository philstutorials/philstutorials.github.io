// This demonstates useful things
// Phil (C) 2019


// Included header files
#include "uart.h"
#include "framebuffer.h"
#include "systimer.h"

// choices of square sizes
enum square_size {SMALL= 8, MED=32, LARGE=64, EX_LARGE=128, MASSIVE=256};

// global board parameter constants
const int ROW_IDX = 0;
const int COL_IDX = 1;
const int SQRSIZE_IDX = 2;

// board parameters
int board_params[3] = {0, 0, EX_LARGE}; // [ ROW_COUNT, COL_COUNT, SQUARE_SIZE]

// timing constants
#define SPEED 300000
#define STARTUP_DELAY 2500000

// function prototypes
void move_row(int);
void move_col(int);
void fill_board();
void animate_my_square();
void print_location(int*);


// global pointer to board map that I initialize in main()
// I am naughty and use a global variable so that the
// board is accessible anywhere in this source
// code file, e.g., from within move_row().
int* board_map;

// location state
int curr_loc[2] = {0, 0};
int prev_loc[2] = {0, 0};

void main()
{
    // initialize the UART terminal
    uart_init();

    // hdmi handshake delay
    microsecond_delay(STARTUP_DELAY);

    // initialize the frame buffer
    initFrameBuffer();

    // use framebuffer parameters and square size to compute column and row count
    init_checkerboard_dims(board_params);

    // initialize board_map to proper dimensions
    int board_map_init[board_params[ROW_IDX]][board_params[COL_IDX]];
    // set my global pointer to this array that is local to main
    board_map = (int*)board_map_init;

    // fill board with checkerboard pattern
    fill_board();

    // draw inital checkerboard to screen
    drawCheckerboard(board_map, board_params);

    while (1) {
       // snake white square around the board
       animate_my_square();
    }
}

// move my special square up or down
void move_row(int delta_row)
{
    // change state appropriately 
    prev_loc[ROW_IDX] = curr_loc[ROW_IDX];
    prev_loc[COL_IDX] = curr_loc[COL_IDX];
    curr_loc[ROW_IDX] += delta_row;
    // draw change
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

// move my special square left or right
void move_col(int delta_col) {
    // change state appropriately 
    prev_loc[ROW_IDX] = curr_loc[ROW_IDX];
    prev_loc[COL_IDX] = curr_loc[COL_IDX];
    curr_loc[COL_IDX] += delta_col;
    // draw change
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

// snake my special square down the board 
void animate_my_square() {
    // start at top left corner
    curr_loc[ROW_IDX] = 0;
    curr_loc[COL_IDX] = 0;
    // set prev_loc to be something else than curr_loc so
    // the first call of draw_move doesn't paint over
    // the curr_loc
    prev_loc[ROW_IDX] = 0;
    prev_loc[COL_IDX] = 1;

    uart_puts("\nSTART ANIMATION\n");
    print_location(curr_loc);
    draw_move(board_map, board_params, curr_loc, prev_loc);
    microsecond_delay(SPEED);

    // clever logic to snake down the checkerboard
    for(int i =0; i<board_params[ROW_IDX]*board_params[COL_IDX]-1; ++i) {
        if (curr_loc[ROW_IDX]%2 == 0) {
            if (curr_loc[COL_IDX]==board_params[COL_IDX]-1) {
                move_row(+1);
            }
            else{
                move_col(+1);
            }
        }
        else {
            if (curr_loc[COL_IDX]==0) {
                move_row(+1);
            }
            else{
                move_col(-1);
            }
        }
        microsecond_delay(SPEED);
        print_location(curr_loc);
    }
    prev_loc[ROW_IDX] = curr_loc[ROW_IDX];
    prev_loc[COL_IDX] = curr_loc[COL_IDX];
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

// uart state printing
void print_location(int* loc)
{
    uart_puts("ROW: ");
    uart_puthex(loc[ROW_IDX]);
    uart_puts("   ");
    uart_puts("COL: ");
    uart_puthex(loc[COL_IDX]);
    uart_puts("\n");
}

// fill board with color indicators (0 = one color, 1 = another color)
// these colors are specified in framebuffer.c
void fill_board()
{
    for (int i = 0; i < board_params[ROW_IDX]; i++) {
        if ((i % 2) == 0) {
            for (int j = 0; j < board_params[COL_IDX]; j++) {
                if ((j % 2) == 0) {
                *((board_map+i*board_params[COL_IDX])+j) = 1;
                }
                else {
                *((board_map+i*board_params[COL_IDX])+j) = 0;
                }
            }
        }
        else {
            for (int j = 0; j < board_params[COL_IDX]; j++) {
                if ((j % 2) == 0) {
                *((board_map+i*board_params[COL_IDX])+j) = 0;
                }
                else {
                *((board_map+i*board_params[COL_IDX])+j) = 1;
                }
            }
        }
    }	    
}

