void initFrameBuffer();
void drawCheckerboard(int* , int* );
void init_checkerboard_dims(int* );
void draw_move(int* , int* , int* , int* );
