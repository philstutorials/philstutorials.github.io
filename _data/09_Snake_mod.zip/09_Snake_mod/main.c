// This program demonstrates how to initialize a frame buffer for a
// 1024 x 768 display, and how to draw on it using a simple checker board
// pattern.

// Included header files
#include "uart.h"
#include "framebuffer.h"
#include "systimer.h"

// global board parameter constants
const int ROW = 0;
const int COL = 1;
const int SQRSIZE = 2;

// timing constants
#define SPEED 300000
#define STARTUP_DELAY 2500000


// Function prototypes
void move_row(int);
void move_col(int);
void fill_board();
void animate_my_square();
void print_location(int*);

enum square_size {SMALL= 8, MED=32, LARGE=64, EX_LARGE=128, MASSIVE=256};

int board_params[3] = {0, 0, EX_LARGE}; // [ ROW_COUNT, COL_COUNT, SQUARE_SIZE]

// global pointer to board map that I initialize below
// this pointer and the other variables outside of the
// main function are accessible anywhere in this source
// code file, e.g., from within move_row().
int* board_map;

int curr_loc[2] = {0, 0};
int prev_loc[2] = {0, 0};

void main()
{
    // Initialize the UART terminal
    uart_init();
    microsecond_delay(STARTUP_DELAY);

    // Initialize the frame buffer
    initFrameBuffer();

    // use framebuffer parameters and square size to compute column and row count
    init_checkerboard_dims(board_params);

    // initialize board_map to proper dimensions
    int board_map_init[board_params[ROW]][board_params[COL]];
    // set my global pointer to this array that is local to main
    board_map = (int*)board_map_init;

    // fill board with checkerboard pattern
    fill_board();

    // draw inital checkerboard to screen
    drawCheckerboard(board_map, board_params);

    while (1) {
       // snake white square around the board
       animate_my_square();
    }
}

// move my special square up or down
void move_row(int delta_row) {
    prev_loc[ROW] = curr_loc[ROW];
    prev_loc[COL] = curr_loc[COL];
    curr_loc[ROW] += delta_row;
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

// move my special square left or right
void move_col(int delta_col) {
    prev_loc[ROW] = curr_loc[ROW];
    prev_loc[COL] = curr_loc[COL];
    curr_loc[COL] += delta_col;
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

// snake my special square down the board 
void animate_my_square()
{
    // start at top left corner
    curr_loc[ROW] = 0;
    curr_loc[COL] = 0;
    // set prev_loc to be something else than curr_loc so
    // the first call of draw_move doesn't paint over
    // the curr_loc
    prev_loc[ROW] = 0;
    prev_loc[COL] = 1;

    uart_puts("\nSTART ANIMATION\n");
    print_location(curr_loc);
    draw_move(board_map, board_params, curr_loc, prev_loc);
    microsecond_delay(SPEED);

    for(int i =0; i<board_params[ROW]*board_params[COL]-1; ++i) {
        if (curr_loc[ROW]%2 == 0) {
            if (curr_loc[COL]==board_params[COL]-1) {
                move_row(+1);
            }
            else{
                move_col(+1);
            }
        }
        else {
            if (curr_loc[COL]==0) {
                move_row(+1);
            }
            else{
                move_col(-1);
            }
        }
        microsecond_delay(SPEED);
        print_location(curr_loc);
    }
    prev_loc[ROW] = curr_loc[ROW];
    prev_loc[COL] = curr_loc[COL];
    draw_move(board_map, board_params, curr_loc, prev_loc);
}

void print_location(int* loc) {
    uart_puts("ROW: ");
    uart_puthex(loc[ROW]);
    uart_puts("   ");
    uart_puts("COL: ");
    uart_puthex(loc[COL]);
    uart_puts("\n");
}


void fill_board() {
    for (int i = 0; i < board_params[ROW]; i++) {
        if ((i % 2) == 0) {
            for (int j = 0; j < board_params[COL]; j++) {
                if ((j % 2) == 0) {
                *((board_map+i*board_params[COL])+j) = 1;
                }
                else {
                *((board_map+i*board_params[COL])+j) = 0;
                }
            }
        }
        else {
            for (int j = 0; j < board_params[COL]; j++) {
                if ((j % 2) == 0) {
                *((board_map+i*board_params[COL])+j) = 0;
                }
                else {
                *((board_map+i*board_params[COL])+j) = 1;
                }
            }
        }
    }	    
}

